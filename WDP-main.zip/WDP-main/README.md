# Real-time messaging Application
The Real-time Messaging Application project is a feature-rich 
chat application that supports real-time communication. Made with GraphQL API, 
MongoDB, React, and secure authentication. It is scalable and made with latest web
technologies.
